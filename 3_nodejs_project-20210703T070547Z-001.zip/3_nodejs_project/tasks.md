# Todo 
[*] Help
[] Organize
[] Tree
[] global 
[] Cover some good practice